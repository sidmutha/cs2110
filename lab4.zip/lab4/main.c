#include<stddef.h>
#include<stdlib.h>
#include<stdio.h>
#include"func.c"

int main(int argc, char **argv){
  FILE *fptr;
  int i,j, n, **matrix, det, **mino;
  fptr = fopen(argv[1],"r");
  n = get_order(fptr);
  matrix = get_matrix_file(fptr, n);
  mino = findMinor(matrix,0, 0, n-1, create_matrix(n-1));
  for(j = 0; j < n-1; j++){
    for(i = 0; i < n-1; i++){
     printf("%d ", mino[j][i]);
    
    }
    printf("\n");  
}
 
  //det = determinant(matrix, n);
  //printf("Determinant: %d\n", det);
  //  free_matrix(matrix, n);
  return 0;
}
