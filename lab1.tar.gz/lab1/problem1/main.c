/* 
 * File:   main.c
 * Author: sidmutha
 *
 * Created on 30 July, 2012, 2:44 PM
 */

#include <stdio.h>
#include <stdlib.h>
#define LENGTH 20
/*
 * 
 */
int main(int argc, char** argv) {
    float a;
    int b;
    char c;
    char d[LENGTH];
    int e;
    
    printf("enter float, int, char, str, hex\n");
    //scanf("%f %d %c %20s %x ",&a,&b,&c,&d,&e);
    scanf("%f",&a);
    scanf("%d",&b);
    getchar();
    scanf("%c",&c);
    scanf("%20s",&d);
    scanf("%x",&e);
    
    printf("\nReverse:");
    printf("%x %s %c %d %f",e,d,c,b,a);
    
    return (EXIT_SUCCESS);
}

