/* 
 * File:   main.c
 * Author: sidmutha
 *
 * Created on 30 July, 2012, 5:02 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include<malloc.h>
/*
 * 
 */
int main(int argc, char** argv) {
    int size;
    char a = 'A';
    
    printf("Enter no of alphabets:");
    scanf("%d",size);
    
    
    
    
    return (EXIT_SUCCESS);
}

